# SLIIT_AF_2018_Past_Paper
Developed using Reactjs , Nodejs, Mongodb along with Spring Boot


In order to run the application 

Clone the project into your local repository 
Once completed
Type npm install to install all the dependencies in both nodejs server and reactjs
To the run the spring boot application just import it as a maven project using eclipse or intellij

