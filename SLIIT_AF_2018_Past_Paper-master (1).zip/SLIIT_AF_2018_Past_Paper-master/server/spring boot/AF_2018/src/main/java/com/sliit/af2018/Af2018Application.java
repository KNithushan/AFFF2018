package com.sliit.af2018;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Af2018Application {

	public static void main(String[] args) {
		SpringApplication.run(Af2018Application.class, args);
	}

}
