package com.sliit.af2018.service;

import com.sliit.af2018.models.Subject;

public interface SubjectService {
	Subject find(String id);
}
