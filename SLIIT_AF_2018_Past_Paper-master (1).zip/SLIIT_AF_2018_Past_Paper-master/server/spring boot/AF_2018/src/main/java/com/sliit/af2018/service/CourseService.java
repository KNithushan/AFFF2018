package com.sliit.af2018.service;

import java.util.Optional;

import com.sliit.af2018.models.Course;

public interface CourseService {
	public Course find(String id);
}
